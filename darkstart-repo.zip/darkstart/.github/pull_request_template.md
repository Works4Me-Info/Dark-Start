**What this changes**


**Checklist**
- [ ] No new requests to other sites (checked in the Network tab)
- [ ] No new dependencies or build step
- [ ] User-supplied text goes in via `textContent`, not `innerHTML`
- [ ] `?v=` numbers bumped in `index.html` / `guide.html` if CSS or JS changed
- [ ] Older backups and exports still import (if the data format changed)
- [ ] `guide.html`, docs and `CHANGELOG.md` updated if people will notice the change
- [ ] Tested in: <!-- browsers -->
