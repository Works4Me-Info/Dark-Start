---
name: Bug report
about: Something doesn't work as described
labels: bug
---

**What happened**


**What you expected**


**Steps to reproduce**
1.
2.
3.

**Browser and version** (e.g. Edge 131, Firefox 133)


**Hosting** (e.g. Apache, IIS, nginx, Netlify, GitHub Pages, locally)


**Console errors** (F12 → Console, if any)


> Found a way the page leaks data or runs code from an imported file? Please don't post it here. See SECURITY.md.
