---
name: Feature idea
about: Suggest an improvement
labels: idea
---

**What would you like to do?**


**Why does it matter to you?** (What are you doing today instead?)


**Privacy check**: would this need the page to contact any other site, or record anything about how people use their links?

- [ ] No
- [ ] Yes / not sure (please explain)

> Dark Start deliberately has no external requests, no dependencies and no server-side storage. See CONTRIBUTING.md.
